﻿Inspera Exam Helper
===================

Double-click "Inspera Exam Helper.exe" to open the graphical helper.

Recommended order:
  1. Prepare my PC for the exam
  2. Am I ready?
  3. Launch Inspera Integrity Browser
  4. If it fails: Why did Inspera fail?

If some apps cannot be closed, right-click the exe and choose Run as administrator,
then run Prepare again.

Fallback shortcuts (if antivirus blocks the exe):
  - Start Inspera Toolkit.cmd
  - Prepare My PC.cmd
  - Check If Ready.cmd
  - Why Did Inspera Fail.cmd

IT staff can edit data\config.json to change log search paths.
See the full README in the source repository for advanced options.
